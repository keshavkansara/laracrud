<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

Route::get('/', 'Auth\LoginController@showLoginForm');
Route::get('/product', 'ProductController@index')->name('product.index');
Route::get('/product/create', 'ProductController@create')->name('product.create');
Route::get('/product/{id}/edit', 'ProductController@edit')->name('product.edit');
Route::get('/product/{id}/delete', 'ProductController@delete')->name('product.delete');
Route::post('/product/update', 'ProductController@update')->name('product.update');
Route::post('/product', 'ProductController@store')->name('product.store');

Route::get('/category', 'ProductCategoryController@index')->name('category.index');
Route::get('/category/create', 'ProductCategoryController@create')->name('category.create');
Route::get('/category/{id}/edit', 'ProductCategoryController@edit')->name('category.edit');
Route::get('/category/{id}/delete', 'ProductCategoryController@delete')->name('category.delete');
Route::post('/category/update', 'ProductCategoryController@update')->name('category.update');
Route::post('/category', 'ProductCategoryController@store')->name('category.store');

Route::get('get-data-my-datatables', ['as'=>'get.data','uses'=>'ProductController@index']);

Route::get('/export', 'ImportExportController@export')->name('export');
Route::get('/importExportView', 'ImportExportController@importExportView');
Route::post('/import', 'ImportExportController@import')->name('import');

Route::get('auth/{provider}', 'Auth\SocialLoginController@redirectToProvider');
Route::get('auth/{provider}/callback', 'Auth\SocialLoginController@handleProviderCallback')->name('AuthCallBackRt');

Route::get('/privacy-policy', 'PrivacyPolicyController@index')->name('privacy.index');
Route::resource('articles', 'ArticleController');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
