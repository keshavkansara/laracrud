@extends('layouts.app')

@section('content')
<div class="container">
  <h3>Categories</h3>
  <a href="{{ route('category.create') }}">Add New Category</a> | <a href="{{ route('product.index') }}">Product Listing</a>
  <br><br>
  @include('inc.flash')
  @if($categories->count())
  <table class="table" id="categoriestable">
    <thead>
      <tr>
        <th>Id</th>
        <th>Category Name</th>
        <th>Action</th>
    </tr>
</thead>
<tbody>
  @foreach($categories as $category)
  <tr>
    <td>{{ $category->id }}</td>
    <td>{{ $category->name }}</td>
    <td>
      <a href="{{ route('category.edit',$category->id) }}">Edit</a> |
      <a href="{{ route('category.delete',$category->id) }}" onclick="return confirm('Are you sure delete?')">delete</a></td>
</tr>      
@endforeach
</tbody>
</table>

<script type="text/javascript">
    jQuery(function() {
        jQuery('#categoriestable').DataTable();
  });
</script>

@else
<p>category not found.</p>
@endif

</div>
@endsection