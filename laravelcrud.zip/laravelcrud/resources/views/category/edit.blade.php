@extends('layouts.app')

@section('content')
<div class="container">
    @include('inc.flash')
    <form action="{{ route('category.update') }}" id="category_form" method="post" enctype="multipart/form-data">
      <input type="hidden" name="cat_id" value="{{ $categories->id }}">
      {{csrf_field()}}

      <div class="form-group">
        <label for="category_name">Category Name:</label>
        <input type="text" name="category_name" class="form-control" id="category_name" value="{{ $categories->name }}">
    </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<script type="text/javascript">
  jQuery(document).ready(function () {
      jQuery('#category_form').validate({ // initialize the plugin
        rules: {
          category_name: {
            required: true
          },
        }
      });
    });
</script>
@endsection
