@extends('layouts.app')

@section('content')
   
<div class="container">
    @include('inc.flash')
            <form action="{{ route('import') }}" method="POST" enctype="multipart/form-data" id="import_form">
                @csrf
                <div class="form-group">
                    <input type="file" name="import_file" class="form-control">
                </div>
                <button class="btn btn-success">Import User Data</button>
                <a class="btn btn-warning" href="{{ route('export') }}">Export User Data</a>
            </form>
</div>

<script type="text/javascript">
    jQuery(document).ready(function () {    
        jQuery('#import_form').validate({ // initialize the plugin
            rules: {
                import_file: {
                    required: true
                }
            }
        });
    });
</script>
   
@endsection
