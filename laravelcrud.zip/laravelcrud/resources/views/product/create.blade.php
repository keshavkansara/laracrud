@extends('layouts.app')

@section('content')
<div class="container">
	@include('inc.flash')
	
	<form action="{{ route('product.store') }}" id="product_form" method="post" enctype="multipart/form-data" >
		{{csrf_field()}}

		<div class="form-group">
			<label for="product_name">Product Name:</label>
			<input type="text" name="product_name" class="form-control" id="product_name" value="{{ old('product_name') }}">
		</div>
		<div class="form-group">
			<label for="product_desc">Product Descrition</label>
			<textarea name="product_desc" id="product_desc" class="form-control">{{ old('product_desc') }}</textarea>
		</div>
		<div class="form-group">
			<label for="category">Catogory:</label>
			<select name="category" id="category" class="form-control"  >
				<option value="">Select Category </option>
				@foreach($categories as $category)
				<option value="{{ $category->id }}">{{ $category->name }}</option>
				@endforeach
			</select>
		</div>

		<div class="form-group">
			<label for="product_img">Product Image:</label>
			<input type="file"  name="product_img" class="form-control" id="product_img" >
		</div>

		<button type="submit" class="btn btn-primary">Submit</button>

	</form>
</div>

<script type="text/javascript">
	jQuery(document).ready(function () {
			jQuery('#product_form').validate({ // initialize the plugin
				rules: {
					product_name: {
						required: true
					},
					product_desc: {
						required: true
					},
					category: {
						required: true,
					},
					product_img: {
						required: true,
						extension: "jpeg|png"
					}
				}
			});
		});
</script>

@endsection
