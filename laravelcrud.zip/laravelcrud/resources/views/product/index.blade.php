@extends('layouts.app')

@section('content')
<div class="container">
  <h3>Products</h3>
  <a href="{{ route('product.create') }}">Add New Product</a> | <a href="{{ route('category.index') }}">Category Listing</a>
  <br><br>
  @include('inc.flash')
  @if($products->count())
  <table class="table table-bordered" id="productstable">
    <thead>
      <tr>
        <th>Id</th>
        <th>Product Name</th>
        <th>Product Description</th>
        <th>Image</th>
        <th>Action</th>
    </tr>
</thead>
<tbody>
  @foreach($products as $product)
  <tr>
    <td>{{ $product->id }}</td>
    <td>{{ $product->name }}</td>
    <td>{{ $product->description }}</td>
    <td> <img src="{{ url('/assets/img/product/'.$product->pro_img) }}"  height="42" width="42"> </td>
    <td><a href="{{ route('product.edit',$product->id) }}">Edit</a> | <a href="{{ route('product.delete',$product->id) }}" onclick="return confirm('Are you sure delete?')">delete</a></td>
</tr>      
@endforeach
</tbody>
</table>

<script type="text/javascript">
    jQuery(function() {
        jQuery('#productstable').DataTable();
	});
</script>

@else
<p>product not found.</p>
@endif

</div>
@endsection