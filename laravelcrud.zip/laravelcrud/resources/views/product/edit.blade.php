@extends('layouts.app')

@section('content')
<div class="container">
    @include('inc.flash')
    <form action="{{ route('product.update') }}" id="product_form" method="post" enctype="multipart/form-data">
      <input type="hidden" name="pro_id" value="{{ $product->id }}">
        {{csrf_field()}}

          <div class="form-group">
            <label for="product_name">Product Name:</label>
            <input type="text" name="product_name" class="form-control" id="product_name" value="{{ $product->name }}">
          </div>
          <div class="form-group">
            <label for="product_desc">Product Descrition</label>
            <textarea name="product_desc" id="product_desc" class="form-control">{{ $product->description }}</textarea>
          </div>
          <div class="form-group">
            <label for="category">Catogory:</label>
            <select name="category" id="category" class="form-control"  >
                <option value="">Select Category </option>
                @foreach($categories as $category)
                  <option value="{{ $category->id }}" {{ $category->id == $product->category_id ? 'selected="selected"' : '' }} >{{ $category->name }}</option>
                @endforeach
            </select>
          </div>

          <div class="form-group">
            <label for="product_img">Product Image:</label>
            <input type="file"  name="product_img" class="form-control" id="product_img" >
          </div>
           <div class="form-group">
               <img src="{{ url('/assets/img/product/'.$product->pro_img) }}"  height="42" width="42"> 
           </div>
      
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
</div>

<script type="text/javascript">
  jQuery(document).ready(function () {
      jQuery('#product_form').validate({ // initialize the plugin
        rules: {
          product_name: {
            required: true
          },
          product_desc: {
            required: true
          },
          category: {
            required: true,
          },
          product_img: {
            required: true,
            extension: "jpeg|png"
          }
        }
      });
    });
</script>

@endsection
