<?php $__env->startSection('content'); ?>
<div class="container">
  <h3>Categories</h3>
  <a href="<?php echo e(route('category.create')); ?>">Add New Category</a> | <a href="<?php echo e(route('product.index')); ?>">Product Listing</a>
  <br><br>
  <?php echo $__env->make('inc.flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php if($categories->count()): ?>
  <table class="table" id="categoriestable">
    <thead>
      <tr>
        <th>Id</th>
        <th>Category Name</th>
        <th>Action</th>
    </tr>
</thead>
<tbody>
  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($category->id); ?></td>
    <td><?php echo e($category->name); ?></td>
    <td>
      <a href="<?php echo e(route('category.edit',$category->id)); ?>">Edit</a> |
      <a href="<?php echo e(route('category.delete',$category->id)); ?>" onclick="return confirm('Are you sure delete?')">delete</a></td>
</tr>      
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

<script type="text/javascript">
    jQuery(function() {
        jQuery('#categoriestable').DataTable();
  });
</script>

<?php else: ?>
<p>category not found.</p>
<?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>