<?php $__env->startSection('content'); ?>
<div class="container">
  <h3>Products</h3>
  <a href="<?php echo e(route('product.create')); ?>">Add New Product</a> | <a href="<?php echo e(route('category.index')); ?>">Category Listing</a>
  <br><br>
  <?php echo $__env->make('inc.flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php if($products->count()): ?>
  <table class="table table-bordered" id="productstable">
    <thead>
      <tr>
        <th>Id</th>
        <th>Product Name</th>
        <th>Product Description</th>
        <th>Image</th>
        <th>Action</th>
    </tr>
</thead>
<tbody>
  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($product->id); ?></td>
    <td><?php echo e($product->name); ?></td>
    <td><?php echo e($product->description); ?></td>
    <td> <img src="<?php echo e(url('/assets/img/product/'.$product->pro_img)); ?>"  height="42" width="42"> </td>
    <td><a href="<?php echo e(route('product.edit',$product->id)); ?>">Edit</a> | <a href="<?php echo e(route('product.delete',$product->id)); ?>" onclick="return confirm('Are you sure delete?')">delete</a></td>
</tr>      
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

<script type="text/javascript">
    jQuery(function() {
        jQuery('#productstable').DataTable();
	});
</script>

<?php else: ?>
<p>product not found.</p>
<?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>