<?php $__env->startSection('content'); ?>
   
<div class="container">
    <?php echo $__env->make('inc.flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data" id="import_form">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="file" name="import_file" class="form-control">
                </div>
                <button class="btn btn-success">Import User Data</button>
                <a class="btn btn-warning" href="<?php echo e(route('export')); ?>">Export User Data</a>
            </form>
</div>

<script type="text/javascript">
    jQuery(document).ready(function () {    
        jQuery('#import_form').validate({ // initialize the plugin
            rules: {
                import_file: {
                    required: true
                }
            }
        });
    });
</script>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>