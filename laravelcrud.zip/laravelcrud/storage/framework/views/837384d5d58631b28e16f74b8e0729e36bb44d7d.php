<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('inc.flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <form action="<?php echo e(route('category.update')); ?>" id="category_form" method="post" enctype="multipart/form-data">
      <input type="hidden" name="cat_id" value="<?php echo e($categories->id); ?>">
      <?php echo e(csrf_field()); ?>


      <div class="form-group">
        <label for="category_name">Category Name:</label>
        <input type="text" name="category_name" class="form-control" id="category_name" value="<?php echo e($categories->name); ?>">
    </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<script type="text/javascript">
  jQuery(document).ready(function () {
      jQuery('#category_form').validate({ // initialize the plugin
        rules: {
          category_name: {
            required: true
          },
        }
      });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>