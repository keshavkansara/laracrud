<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Product;

class ProductController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
	}

	public function index()
	{
		$categories = Category::all();
		$products = Product::all();

		return view('product.index',[
			'categories' => $categories,
			'products' => $products
		]);
	}

	public function create()
	{
		$categories = Category::all();

		return view('product.create',[
			'categories' => $categories
		]);
	}

	public function edit($id)
	{
		$product = Product::find($id);
		$categories = Category::all();

		return view('product.edit',[
			'categories' => $categories,
			'product' => $product
		]);
	}

	public function store(Request $res)
	{
		$this->validate($res,[
			'product_name' => 'required',
			'product_desc' => 'required' ,
			'category' => 'required|exists:products_category,id',
			'product_img' => 'required|image' 
		]);

		$pro_img = time().'.'.$res->product_img->getClientOriginalExtension();

		$res->product_img->move(public_path('assets/img/product'), $pro_img);

		Product::create([
			'name' => $res->product_name,
			'description' => $res->product_desc,
			'category_id' => $res->category,
			'pro_img' => $pro_img,
		]);

		session()->flash('success','product data save successfully');

		return redirect()->route('product.index');
	}

	public function update(Request $res)
	{
		$this->validate($res,[
			'product_name' => 'required',
			'product_desc' => 'required' ,
			'category' => 'required|exists:products_category,id',
		]);

		$product_m= Product::find($res->pro_id);

		$product_m->update([
			'name' => $res->product_name,
			'description' => $res->product_desc,
			'category_id' => $res->category
		]);

		if($res->has('product_img'))
		{	
			$pro_img = time().'.'.$res->product_img->getClientOriginalExtension();
			$res->product_img->move(public_path('assets/img/product'), $pro_img);
			$product_m= Product::find($res->pro_id);
			$product_m->update([
				'pro_img' => $pro_img
			]);
		}

		session()->flash('success','product data updated successfully');

		return redirect()->route('product.index');
	}

	public function delete($id)
	{
		$product_m= Product::find($id)->delete();

		session()->flash('success','product deleted successfully');

		return redirect()->route('product.index');
	}
}