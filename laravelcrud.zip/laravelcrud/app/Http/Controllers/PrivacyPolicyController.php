<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Product;

class PrivacyPolicyController extends Controller
{
	public function index()
	{
		return view('privacy.index',[]);
	}
}