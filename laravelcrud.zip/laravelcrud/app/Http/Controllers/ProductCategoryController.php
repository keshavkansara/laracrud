<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class ProductCategoryController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
	}

	public function index()
	{
		$categories = Category::paginate(2);
		
		return view('category.index',[
			'categories' => $categories
		]);
	}

	public function create()
	{
		return view('category.create',[
		]);
	}

	public function edit($id)
	{
		$categories = Category::find($id);
		
		return view('category.edit',[
			'categories' => $categories
		]);
	}

	public function store(Request $res)
	{
		$this->validate($res,[
			'category_name' => 'required'
		]);

		Category::create([
			'name' => $res->category_name
		]);

		session()->flash('success','categroy data save successfully');

		return redirect()->route('category.index');
	}

	public function update(Request $res)
	{
		$this->validate($res,[
			'category_name' => 'required'
		]);

		$category_m= Category::find($res->cat_id);

		$category_m->update([
			'name' => $res->category_name
		]);

		session()->flash('success','Category data updated successfully');

		return redirect()->route('category.index');
	}

	public function delete($id)
	{
		$category_m= Category::find($id)->delete();

		session()->flash('success','Category deleted successfully');

		return redirect()->route('category.index');
	}
}